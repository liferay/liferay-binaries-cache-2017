For documentation on how to use, launch, and/or embed the Felix framework,
please refer to the documentation accompanying the full Felix installation
or the "main" Felix subproject. Documentation is also available from our
web site at:

    http://cwiki.apache.org/FELIX/documentation.html
